package com.example.weighttrackerjasperconneway;

import android.content.pm.PackageManager;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.widget.ToggleButton;

public class Settings extends AppCompatActivity {

    // permission code for notifications
    private static final int PERMISSION_REQUEST_CODE = 100;
    // toggle button to turn notif ON or OFF
    private ToggleButton toggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings);

        // set each view by id
        toggle = findViewById(R.id.toggleNotif);
        TextView settings = findViewById(R.id.settingsTitle);
        TextView message = findViewById(R.id.message);
        TextView clickON = findViewById(R.id.clickON);
        TextView notifSection = findViewById(R.id.notifSection);

        // check if push notifications have been accepted, set toggle if necessary
        toggle.setChecked(ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED);

        // listen for toggle input
        toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView,
                                         boolean isChecked) {
                if (isChecked) {
                    // turn on
                    enableToggleNotif(); // call method to ask for permission
                    toggle.setChecked(true);
                } else {
                    // turn off (could not figure out the background to turn this off with toggle)
                    toggle.setChecked(false);
                }
            }
        });
    }

    public void enableToggleNotif() {
        // Check if the permission has been granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            // Otherwise, request permission
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    PERMISSION_REQUEST_CODE);
        } else {
            // Permission granted, proceed with push notifications
            initializePushNotifications();
        }
    }

    private void initializePushNotifications() {
        // initialize notifs
        Toast.makeText(this, "Push Notifications Initialized", Toast.LENGTH_SHORT).show();
    }

}
