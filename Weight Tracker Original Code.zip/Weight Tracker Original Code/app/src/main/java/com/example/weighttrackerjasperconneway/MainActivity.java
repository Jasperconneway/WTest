package com.example.weighttrackerjasperconneway;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.view.View;
import android.widget.Button;
import android.os.Bundle;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.widget.GridView;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_CODE = 100;
    private WTDatabase db;
    private GridView gridView;
    private String username;
    private String password;
    private ArrayList<Model> userWeight;
    private Button addWeightButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        gridView = findViewById(R.id.grid_view);
        userWeight = new ArrayList<>();

        // gather intent from previous activity
        Intent intent = getIntent();
        username = intent.getStringExtra("username");
        password = intent.getStringExtra("password");


        db = new WTDatabase(MainActivity.this);

        // get user id specific to user
        String userId = db.getUserId(username, password);

        // create grid based on user with user id
        if (!userId.equalsIgnoreCase("-1")) {
            userWeight = db.getAllUserWeight(userId);

            // creates the grid view
            GridViewAdapter adapter = new GridViewAdapter(this, userWeight);
            gridView.setAdapter(adapter);
        }


        // enable adding weight
        addWeightButton = findViewById(R.id.addWeight);

        // Check if the permission is already granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            // Request the permission
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    PERMISSION_REQUEST_CODE);
        } else {
            // Permission already granted, proceed with push notifications
            initializePushNotifications();
        }



    }

    public void clickAddWeight() {
        addWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Enter weight and date.", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, AddUserWeight.class);
                intent.putExtra("username", username); // allow next activity to use
                intent.putExtra("password", password); // allow next activity to use
                startActivity(intent); // start
            }
        });
    }

    private void initializePushNotifications() {
        // Your code to initialize push notifications
        Toast.makeText(this, "Push Notifications Initialized", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, proceed with push notifications
                initializePushNotifications();

            } else {
                // Permission denied, show a message to the user
                Toast.makeText(this, "Permission Denied. Push Notifications cannot be enabled.", Toast.LENGTH_SHORT).show();
            }
        }

    }


}
