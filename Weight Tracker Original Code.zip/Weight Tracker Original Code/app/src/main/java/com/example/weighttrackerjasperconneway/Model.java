package com.example.weighttrackerjasperconneway;

public class Model {
    private String weight;
    private String date;

    public Model(String weight, String date) {
        this.weight = weight;
        this.date = date;
    }

    public String getWeight() {
        return weight;
    }

    public String getDate() {
        return date;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
